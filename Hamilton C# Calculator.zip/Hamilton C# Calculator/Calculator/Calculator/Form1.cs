﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int answer = 0;
        
        private void button2_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(txtnum1.Text);
            int num2 = Convert.ToInt32(txtnum2.Text);

            answer = num1 - num2;
            MessageBox.Show("Your answer is " + answer, "Subtract");
            radioButton1.Checked = false;
            radioButton2.Checked = true;
            radioButton3.Checked = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(txtnum1.Text);
            int num2 = Convert.ToInt32(txtnum2.Text);
            MessageBox.Show("Your answer is " + answer, "Add");
            answer = num1 + num2;
            radioButton3.Checked = false;
            radioButton2.Checked = false;
            radioButton1.Checked = true;
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(txtnum1.Text);
            int num2 = Convert.ToInt32(txtnum2.Text);
            answer =num1 * num2;
            MessageBox.Show("Your answer is " + answer, "Multiply");
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtnum2.Text = "";
            txtnum1.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure you want to exit", "exit", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            }


        }
    }
}
